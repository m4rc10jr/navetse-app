import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _adad757a = () => interopDefault(import('..\\pages\\budgets\\index.vue' /* webpackChunkName: "pages/budgets/index" */))
const _f90d3554 = () => interopDefault(import('..\\pages\\companies\\index.vue' /* webpackChunkName: "pages/companies/index" */))
const _2df5098e = () => interopDefault(import('..\\pages\\company.vue' /* webpackChunkName: "pages/company" */))
const _6d67096c = () => interopDefault(import('..\\pages\\employees\\index.vue' /* webpackChunkName: "pages/employees/index" */))
const _0c4e8b9a = () => interopDefault(import('..\\pages\\inputs\\index.vue' /* webpackChunkName: "pages/inputs/index" */))
const _3c035e8c = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _0ef41210 = () => interopDefault(import('..\\pages\\production-orders\\index.vue' /* webpackChunkName: "pages/production-orders/index" */))
const _56d9e0ba = () => interopDefault(import('..\\pages\\profile.vue' /* webpackChunkName: "pages/profile" */))
const _7cc3069c = () => interopDefault(import('..\\pages\\reports\\index.vue' /* webpackChunkName: "pages/reports/index" */))
const _74f2f105 = () => interopDefault(import('..\\pages\\sales\\index.vue' /* webpackChunkName: "pages/sales/index" */))
const _6a79c056 = () => interopDefault(import('..\\pages\\schedules\\index.vue' /* webpackChunkName: "pages/schedules/index" */))
const _4364ce34 = () => interopDefault(import('..\\pages\\stocks\\index.vue' /* webpackChunkName: "pages/stocks/index" */))
const _cbde07f4 = () => interopDefault(import('..\\pages\\admin\\accounts.vue' /* webpackChunkName: "pages/admin/accounts" */))
const _1e61d82e = () => interopDefault(import('..\\pages\\admin\\cities.vue' /* webpackChunkName: "pages/admin/cities" */))
const _24852222 = () => interopDefault(import('..\\pages\\admin\\states.vue' /* webpackChunkName: "pages/admin/states" */))
const _5d530673 = () => interopDefault(import('..\\pages\\admin\\sub-accounts.vue' /* webpackChunkName: "pages/admin/sub-accounts" */))
const _47ed2b70 = () => interopDefault(import('..\\pages\\admin\\type-payments.vue' /* webpackChunkName: "pages/admin/type-payments" */))
const _30bbd6ff = () => interopDefault(import('..\\pages\\admin\\units.vue' /* webpackChunkName: "pages/admin/units" */))
const _aa5d5f2c = () => interopDefault(import('..\\pages\\admin\\users\\index.vue' /* webpackChunkName: "pages/admin/users/index" */))
const _13edee06 = () => interopDefault(import('..\\pages\\password\\forgot.vue' /* webpackChunkName: "pages/password/forgot" */))
const _06159936 = () => interopDefault(import('..\\pages\\password\\reset.vue' /* webpackChunkName: "pages/password/reset" */))
const _35930768 = () => interopDefault(import('..\\pages\\records\\authorization\\index.vue' /* webpackChunkName: "pages/records/authorization/index" */))
const _7bd64a86 = () => interopDefault(import('..\\pages\\records\\department\\index.vue' /* webpackChunkName: "pages/records/department/index" */))
const _a97e3fe8 = () => interopDefault(import('..\\pages\\records\\entity\\index.vue' /* webpackChunkName: "pages/records/entity/index" */))
const _f6bd47c8 = () => interopDefault(import('..\\pages\\records\\goal\\index.vue' /* webpackChunkName: "pages/records/goal/index" */))
const _636ae01c = () => interopDefault(import('..\\pages\\records\\item\\index.vue' /* webpackChunkName: "pages/records/item/index" */))
const _7cbab5aa = () => interopDefault(import('..\\pages\\admin\\components\\AccountForm.vue' /* webpackChunkName: "pages/admin/components/AccountForm" */))
const _0ff3eeb6 = () => interopDefault(import('..\\pages\\admin\\components\\CityForm.vue' /* webpackChunkName: "pages/admin/components/CityForm" */))
const _318af40f = () => interopDefault(import('..\\pages\\admin\\components\\StateForm.vue' /* webpackChunkName: "pages/admin/components/StateForm" */))
const _48847af2 = () => interopDefault(import('..\\pages\\admin\\components\\SubAccountForm.vue' /* webpackChunkName: "pages/admin/components/SubAccountForm" */))
const _8a283f2c = () => interopDefault(import('..\\pages\\admin\\components\\TypePaymentForm.vue' /* webpackChunkName: "pages/admin/components/TypePaymentForm" */))
const _067d1fbe = () => interopDefault(import('..\\pages\\admin\\components\\UnitForm.vue' /* webpackChunkName: "pages/admin/components/UnitForm" */))
const _bafc0e22 = () => interopDefault(import('..\\pages\\companies\\components\\CompanyForm.vue' /* webpackChunkName: "pages/companies/components/CompanyForm" */))
const _709eeb07 = () => interopDefault(import('..\\pages\\inputs\\components\\FormLowInstallment.vue' /* webpackChunkName: "pages/inputs/components/FormLowInstallment" */))
const _14ce7a72 = () => interopDefault(import('..\\pages\\admin\\users\\components\\form.vue' /* webpackChunkName: "pages/admin/users/components/form" */))
const _7ae46d50 = () => interopDefault(import('..\\pages\\records\\authorization\\components\\form.vue' /* webpackChunkName: "pages/records/authorization/components/form" */))
const _27694e3f = () => interopDefault(import('..\\pages\\records\\department\\components\\form.vue' /* webpackChunkName: "pages/records/department/components/form" */))
const _3a6b9ce0 = () => interopDefault(import('..\\pages\\records\\entity\\components\\form.vue' /* webpackChunkName: "pages/records/entity/components/form" */))
const _16c2e900 = () => interopDefault(import('..\\pages\\records\\goal\\components\\form.vue' /* webpackChunkName: "pages/records/goal/components/form" */))
const _55ab8cf8 = () => interopDefault(import('..\\pages\\records\\item\\_id.vue' /* webpackChunkName: "pages/records/item/_id" */))
const _0c53d24c = () => interopDefault(import('..\\pages\\base\\_id.vue' /* webpackChunkName: "pages/base/_id" */))
const _1c84872a = () => interopDefault(import('..\\pages\\budgets\\_id.vue' /* webpackChunkName: "pages/budgets/_id" */))
const _e8a67584 = () => interopDefault(import('..\\pages\\companies\\_id.vue' /* webpackChunkName: "pages/companies/_id" */))
const _2bc076d4 = () => interopDefault(import('..\\pages\\employees\\_id.vue' /* webpackChunkName: "pages/employees/_id" */))
const _8d42a6fc = () => interopDefault(import('..\\pages\\inputs\\_id.vue' /* webpackChunkName: "pages/inputs/_id" */))
const _ced55140 = () => interopDefault(import('..\\pages\\production-orders\\_id.vue' /* webpackChunkName: "pages/production-orders/_id" */))
const _7fb91ea6 = () => interopDefault(import('..\\pages\\sales\\_id.vue' /* webpackChunkName: "pages/sales/_id" */))
const _0ad1137d = () => interopDefault(import('..\\pages\\schedules\\_id.vue' /* webpackChunkName: "pages/schedules/_id" */))
const _5bcec664 = () => interopDefault(import('..\\pages\\stocks\\_id.vue' /* webpackChunkName: "pages/stocks/_id" */))
const _1856ada3 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/budgets",
    component: _adad757a,
    name: "budgets"
  }, {
    path: "/companies",
    component: _f90d3554,
    name: "companies"
  }, {
    path: "/company",
    component: _2df5098e,
    name: "company"
  }, {
    path: "/employees",
    component: _6d67096c,
    name: "employees"
  }, {
    path: "/inputs",
    component: _0c4e8b9a,
    name: "inputs"
  }, {
    path: "/login",
    component: _3c035e8c,
    name: "login"
  }, {
    path: "/production-orders",
    component: _0ef41210,
    name: "production-orders"
  }, {
    path: "/profile",
    component: _56d9e0ba,
    name: "profile"
  }, {
    path: "/reports",
    component: _7cc3069c,
    name: "reports"
  }, {
    path: "/sales",
    component: _74f2f105,
    name: "sales"
  }, {
    path: "/schedules",
    component: _6a79c056,
    name: "schedules"
  }, {
    path: "/stocks",
    component: _4364ce34,
    name: "stocks"
  }, {
    path: "/admin/accounts",
    component: _cbde07f4,
    name: "admin-accounts"
  }, {
    path: "/admin/cities",
    component: _1e61d82e,
    name: "admin-cities"
  }, {
    path: "/admin/states",
    component: _24852222,
    name: "admin-states"
  }, {
    path: "/admin/sub-accounts",
    component: _5d530673,
    name: "admin-sub-accounts"
  }, {
    path: "/admin/type-payments",
    component: _47ed2b70,
    name: "admin-type-payments"
  }, {
    path: "/admin/units",
    component: _30bbd6ff,
    name: "admin-units"
  }, {
    path: "/admin/users",
    component: _aa5d5f2c,
    name: "admin-users"
  }, {
    path: "/password/forgot",
    component: _13edee06,
    name: "password-forgot"
  }, {
    path: "/password/reset",
    component: _06159936,
    name: "password-reset"
  }, {
    path: "/records/authorization",
    component: _35930768,
    name: "records-authorization"
  }, {
    path: "/records/department",
    component: _7bd64a86,
    name: "records-department"
  }, {
    path: "/records/entity",
    component: _a97e3fe8,
    name: "records-entity"
  }, {
    path: "/records/goal",
    component: _f6bd47c8,
    name: "records-goal"
  }, {
    path: "/records/item",
    component: _636ae01c,
    name: "records-item"
  }, {
    path: "/admin/components/AccountForm",
    component: _7cbab5aa,
    name: "admin-components-AccountForm"
  }, {
    path: "/admin/components/CityForm",
    component: _0ff3eeb6,
    name: "admin-components-CityForm"
  }, {
    path: "/admin/components/StateForm",
    component: _318af40f,
    name: "admin-components-StateForm"
  }, {
    path: "/admin/components/SubAccountForm",
    component: _48847af2,
    name: "admin-components-SubAccountForm"
  }, {
    path: "/admin/components/TypePaymentForm",
    component: _8a283f2c,
    name: "admin-components-TypePaymentForm"
  }, {
    path: "/admin/components/UnitForm",
    component: _067d1fbe,
    name: "admin-components-UnitForm"
  }, {
    path: "/companies/components/CompanyForm",
    component: _bafc0e22,
    name: "companies-components-CompanyForm"
  }, {
    path: "/inputs/components/FormLowInstallment",
    component: _709eeb07,
    name: "inputs-components-FormLowInstallment"
  }, {
    path: "/admin/users/components/form",
    component: _14ce7a72,
    name: "admin-users-components-form"
  }, {
    path: "/records/authorization/components/form",
    component: _7ae46d50,
    name: "records-authorization-components-form"
  }, {
    path: "/records/department/components/form",
    component: _27694e3f,
    name: "records-department-components-form"
  }, {
    path: "/records/entity/components/form",
    component: _3a6b9ce0,
    name: "records-entity-components-form"
  }, {
    path: "/records/goal/components/form",
    component: _16c2e900,
    name: "records-goal-components-form"
  }, {
    path: "/records/item/:id",
    component: _55ab8cf8,
    name: "records-item-id"
  }, {
    path: "/base/:id?",
    component: _0c53d24c,
    name: "base-id"
  }, {
    path: "/budgets/:id",
    component: _1c84872a,
    name: "budgets-id"
  }, {
    path: "/companies/:id",
    component: _e8a67584,
    name: "companies-id"
  }, {
    path: "/employees/:id",
    component: _2bc076d4,
    name: "employees-id"
  }, {
    path: "/inputs/:id",
    component: _8d42a6fc,
    name: "inputs-id"
  }, {
    path: "/production-orders/:id?",
    component: _ced55140,
    name: "production-orders-id"
  }, {
    path: "/sales/:id",
    component: _7fb91ea6,
    name: "sales-id"
  }, {
    path: "/schedules/:id",
    component: _0ad1137d,
    name: "schedules-id"
  }, {
    path: "/stocks/:id",
    component: _5bcec664,
    name: "stocks-id"
  }, {
    path: "/",
    component: _1856ada3,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
