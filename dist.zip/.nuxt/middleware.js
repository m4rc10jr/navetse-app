const middleware = {}

middleware['auth'] = require('..\\middleware\\auth.js')
middleware['auth'] = middleware['auth'].default || middleware['auth']

middleware['authorize'] = require('..\\middleware\\authorize.js')
middleware['authorize'] = middleware['authorize'].default || middleware['authorize']

export default middleware
