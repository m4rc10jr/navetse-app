export const Alert = () => import('../..\\components\\Alert.vue' /* webpackChunkName: "components/alert" */).then(c => wrapFunctional(c.default || c))
export const Blank = () => import('../..\\components\\Blank.vue' /* webpackChunkName: "components/blank" */).then(c => wrapFunctional(c.default || c))
export const Breadcrumb = () => import('../..\\components\\Breadcrumb.vue' /* webpackChunkName: "components/breadcrumb" */).then(c => wrapFunctional(c.default || c))
export const Chip = () => import('../..\\components\\Chip.vue' /* webpackChunkName: "components/chip" */).then(c => wrapFunctional(c.default || c))
export const Column = () => import('../..\\components\\Column.vue' /* webpackChunkName: "components/column" */).then(c => wrapFunctional(c.default || c))
export const CustomIcon = () => import('../..\\components\\CustomIcon.vue' /* webpackChunkName: "components/custom-icon" */).then(c => wrapFunctional(c.default || c))
export const Logo = () => import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c))
export const NavItems = () => import('../..\\components\\NavItems.vue' /* webpackChunkName: "components/nav-items" */).then(c => wrapFunctional(c.default || c))
export const Notify = () => import('../..\\components\\Notify.vue' /* webpackChunkName: "components/notify" */).then(c => wrapFunctional(c.default || c))
export const Page = () => import('../..\\components\\Page.vue' /* webpackChunkName: "components/page" */).then(c => wrapFunctional(c.default || c))
export const Print = () => import('../..\\components\\Print.vue' /* webpackChunkName: "components/print" */).then(c => wrapFunctional(c.default || c))
export const RowInfo = () => import('../..\\components\\RowInfo.vue' /* webpackChunkName: "components/row-info" */).then(c => wrapFunctional(c.default || c))
export const ButtonAdd = () => import('../..\\components\\Button\\Add.vue' /* webpackChunkName: "components/button-add" */).then(c => wrapFunctional(c.default || c))
export const ButtonDelete = () => import('../..\\components\\Button\\Delete.vue' /* webpackChunkName: "components/button-delete" */).then(c => wrapFunctional(c.default || c))
export const CardWidget = () => import('../..\\components\\Card\\Widget.vue' /* webpackChunkName: "components/card-widget" */).then(c => wrapFunctional(c.default || c))
export const FilterOrder = () => import('../..\\components\\Filter\\Order.vue' /* webpackChunkName: "components/filter-order" */).then(c => wrapFunctional(c.default || c))
export const EditorInstallment = () => import('../..\\components\\Editor\\Installment.vue' /* webpackChunkName: "components/editor-installment" */).then(c => wrapFunctional(c.default || c))
export const EditorItem = () => import('../..\\components\\Editor\\Item.vue' /* webpackChunkName: "components/editor-item" */).then(c => wrapFunctional(c.default || c))
export const DynamicList = () => import('../..\\components\\Dynamic\\List.vue' /* webpackChunkName: "components/dynamic-list" */).then(c => wrapFunctional(c.default || c))
export const FormAction = () => import('../..\\components\\Form\\Action.vue' /* webpackChunkName: "components/form-action" */).then(c => wrapFunctional(c.default || c))
export const InputCompetenceDate = () => import('../..\\components\\Input\\CompetenceDate.vue' /* webpackChunkName: "components/input-competence-date" */).then(c => wrapFunctional(c.default || c))
export const InputCurrency = () => import('../..\\components\\Input\\Currency.vue' /* webpackChunkName: "components/input-currency" */).then(c => wrapFunctional(c.default || c))
export const InputDate = () => import('../..\\components\\Input\\Date.vue' /* webpackChunkName: "components/input-date" */).then(c => wrapFunctional(c.default || c))
export const InputPassword = () => import('../..\\components\\Input\\Password.vue' /* webpackChunkName: "components/input-password" */).then(c => wrapFunctional(c.default || c))
export const InputText = () => import('../..\\components\\Input\\Text.vue' /* webpackChunkName: "components/input-text" */).then(c => wrapFunctional(c.default || c))
export const InputTime = () => import('../..\\components\\Input\\Time.vue' /* webpackChunkName: "components/input-time" */).then(c => wrapFunctional(c.default || c))
export const InputTimeMask = () => import('../..\\components\\Input\\TimeMask.vue' /* webpackChunkName: "components/input-time-mask" */).then(c => wrapFunctional(c.default || c))
export const LayoutFooter = () => import('../..\\components\\Layout\\Footer.vue' /* webpackChunkName: "components/layout-footer" */).then(c => wrapFunctional(c.default || c))
export const LayoutLoading = () => import('../..\\components\\Layout\\Loading.vue' /* webpackChunkName: "components/layout-loading" */).then(c => wrapFunctional(c.default || c))
export const LayoutSwichAccount = () => import('../..\\components\\Layout\\SwichAccount.vue' /* webpackChunkName: "components/layout-swich-account" */).then(c => wrapFunctional(c.default || c))
export const ModalConfimation = () => import('../..\\components\\Modal\\Confimation.vue' /* webpackChunkName: "components/modal-confimation" */).then(c => wrapFunctional(c.default || c))
export const ModalForm = () => import('../..\\components\\Modal\\Form.vue' /* webpackChunkName: "components/modal-form" */).then(c => wrapFunctional(c.default || c))
export const Modal = () => import('../..\\components\\Modal\\Index.vue' /* webpackChunkName: "components/modal" */).then(c => wrapFunctional(c.default || c))
export const SelectClient = () => import('../..\\components\\Select\\Client.vue' /* webpackChunkName: "components/select-client" */).then(c => wrapFunctional(c.default || c))
export const SelectDefault = () => import('../..\\components\\Select\\Default.vue' /* webpackChunkName: "components/select-default" */).then(c => wrapFunctional(c.default || c))
export const SelectDynamic = () => import('../..\\components\\Select\\Dynamic.vue' /* webpackChunkName: "components/select-dynamic" */).then(c => wrapFunctional(c.default || c))
export const SelectEmployee = () => import('../..\\components\\Select\\Employee.vue' /* webpackChunkName: "components/select-employee" */).then(c => wrapFunctional(c.default || c))
export const SelectEntity = () => import('../..\\components\\Select\\Entity.vue' /* webpackChunkName: "components/select-entity" */).then(c => wrapFunctional(c.default || c))
export const SelectItem = () => import('../..\\components\\Select\\Item.vue' /* webpackChunkName: "components/select-item" */).then(c => wrapFunctional(c.default || c))
export const SelectUnit = () => import('../..\\components\\Select\\Unit.vue' /* webpackChunkName: "components/select-unit" */).then(c => wrapFunctional(c.default || c))
export const UploaderGallery = () => import('../..\\components\\Uploader\\Gallery.vue' /* webpackChunkName: "components/uploader-gallery" */).then(c => wrapFunctional(c.default || c))
export const UtilsShow = () => import('../..\\components\\Utils\\Show.vue' /* webpackChunkName: "components/utils-show" */).then(c => wrapFunctional(c.default || c))
export const EditorComponentsInputDoc = () => import('../..\\components\\Editor\\components\\InputDoc.vue' /* webpackChunkName: "components/editor-components-input-doc" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
